Hello and welcome to my webhook message sender!
I am not responsable for what you will do with this python tool.
If you don't have all the packages installed then run "install_packs.bat" and it should be done!
It's pretty simple on how to use it so there should be nothing to explain

But if you don't know how to make a webhook: 
   - Go in a discord server
   - Go to setting
   - Select "Integrations"
   - Open "Webhooks"
   - Create a new one (Personalize it how you want)
   - Select the channel you want the Webhook to send the message
   - Copy the URL and insert it in this tool!

Have a good day by Primex (user: celestial_ontopx)
   Server discord --> https://discord.gg/W43Vsxdm <